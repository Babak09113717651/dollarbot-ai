import os, sqlite3, time
from datetime import datetime, timezone
from flask import Flask, jsonify, render_template, request
import requests

app = Flask(__name__)
DB_PATH = os.getenv("DOLLARBOT_DB", "dollarbot.db")
BINANCE = "https://api.binance.com"
SYMBOLS = ["BTCUSDT", "ETHUSDT", "SOLUSDT", "BNBUSDT", "XRPUSDT"]

def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with db() as c:
        c.execute("""CREATE TABLE IF NOT EXISTS signal_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created_at TEXT NOT NULL, symbol TEXT NOT NULL,
            signal TEXT NOT NULL, price REAL, ma7 REAL, ma25 REAL
        )""")
        c.execute("""CREATE TABLE IF NOT EXISTS paper_trades (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created_at TEXT NOT NULL, symbol TEXT NOT NULL,
            side TEXT NOT NULL, quantity REAL NOT NULL, price REAL NOT NULL,
            status TEXT NOT NULL DEFAULT 'PAPER'
        )""")
        c.execute("""CREATE TABLE IF NOT EXISTS app_settings (
            key TEXT PRIMARY KEY, value TEXT NOT NULL
        )""")
        c.execute("INSERT OR IGNORE INTO app_settings(key,value) VALUES('paper_balance','10000')")
init_db()

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/api/health")
def health():
    return jsonify({"ok": True, "app": "DollarBot AI", "mode": "market-data + paper-trading", "live_orders_enabled": False})

@app.route("/api/crypto")
def crypto():
    try:
        r = requests.get(f"{BINANCE}/api/v3/ticker/24hr", timeout=10)
        r.raise_for_status()
        wanted = set(SYMBOLS)
        rows = []
        for x in r.json():
            if x.get("symbol") in wanted:
                rows.append({"symbol": x["symbol"], "price": float(x["lastPrice"]),
                             "change": float(x["priceChangePercent"]), "volume": float(x["quoteVolume"])})
        rows.sort(key=lambda x: SYMBOLS.index(x["symbol"]))
        return jsonify({"source": "Binance public market data", "updated_at": datetime.now(timezone.utc).isoformat(), "data": rows})
    except requests.RequestException:
        return jsonify({"error": "بازار رمزارز موقتاً در دسترس نیست."}), 502

@app.route("/api/forex")
def forex():
    key = os.getenv("TWELVEDATA_API_KEY", "").strip()
    if not key:
        return jsonify({"configured": False, "message": "برای داده زنده فارکس و طلا باید TWELVEDATA_API_KEY را روی سرور تنظیم کنید.", "data": []})
    symbols = ["EUR/USD", "GBP/USD", "USD/JPY", "XAU/USD"]
    results = []
    for symbol in symbols:
        try:
            r = requests.get("https://api.twelvedata.com/price", params={"symbol": symbol, "apikey": key}, timeout=10)
            payload = r.json()
            if "price" in payload:
                results.append({"symbol": symbol, "price": float(payload["price"])})
            else:
                results.append({"symbol": symbol, "error": payload.get("message", "Data unavailable")})
        except requests.RequestException:
            results.append({"symbol": symbol, "error": "داده موقتاً در دسترس نیست"})
    return jsonify({"configured": True, "source": "Twelve Data", "data": results})

@app.route("/api/signals")
def signals():
    output = []
    for symbol in SYMBOLS[:3]:
        try:
            r = requests.get(f"{BINANCE}/api/v3/klines", params={"symbol": symbol, "interval": "1h", "limit": 50}, timeout=10)
            r.raise_for_status()
            candles = r.json()
            closes = [float(c[4]) for c in candles]
            short = sum(closes[-7:]) / 7
            long = sum(closes[-25:]) / 25
            if short > long * 1.002:
                sig = "روند صعودی"
            elif short < long * 0.998:
                sig = "روند نزولی"
            else:
                sig = "خنثی"
            row = {"symbol": symbol, "signal": sig, "last": closes[-1], "ma7": round(short, 6), "ma25": round(long, 6)}
            output.append(row)
            with db() as c:
                c.execute("INSERT INTO signal_log(created_at,symbol,signal,price,ma7,ma25) VALUES(?,?,?,?,?,?)",
                          (datetime.now(timezone.utc).isoformat(), symbol, sig, closes[-1], short, long))
        except (requests.RequestException, ValueError, KeyError, IndexError):
            output.append({"symbol": symbol, "signal": "داده در دسترس نیست"})
    return jsonify({"note": "تحلیل ساده میانگین متحرک است؛ توصیه مالی یا تضمین سود نیست.", "data": output})

@app.route("/api/history")
def history():
    with db() as c:
        rows = c.execute("SELECT * FROM signal_log ORDER BY id DESC LIMIT 30").fetchall()
    return jsonify({"data": [dict(x) for x in rows]})

@app.route("/api/paper/balance", methods=["GET"])
def paper_balance():
    with db() as c:
        row = c.execute("SELECT value FROM app_settings WHERE key='paper_balance'").fetchone()
        trades = c.execute("SELECT COUNT(*) n FROM paper_trades").fetchone()["n"]
    return jsonify({"balance": float(row["value"]), "currency": "USDT", "is_virtual": True, "trades_count": trades})

@app.route("/api/paper/trades", methods=["GET", "POST"])
def paper_trades():
    if request.method == "GET":
        with db() as c:
            rows = c.execute("SELECT * FROM paper_trades ORDER BY id DESC LIMIT 50").fetchall()
        return jsonify({"data": [dict(x) for x in rows], "is_virtual": True})
    payload = request.get_json(silent=True) or {}
    symbol = str(payload.get("symbol", "BTCUSDT")).upper()
    side = str(payload.get("side", "")).upper()
    try:
        qty = float(payload.get("quantity", 0))
        price = float(payload.get("price", 0))
    except (TypeError, ValueError):
        return jsonify({"error": "مقدار و قیمت باید عدد باشند."}), 400
    if symbol not in SYMBOLS or side not in ("BUY", "SELL") or qty <= 0 or price <= 0:
        return jsonify({"error": "نماد، جهت معامله یا مقدار نامعتبر است."}), 400
    # Simulated trade only; does not send orders to an exchange.
    with db() as c:
        c.execute("INSERT INTO paper_trades(created_at,symbol,side,quantity,price,status) VALUES(?,?,?,?,?,'PAPER')",
                  (datetime.now(timezone.utc).isoformat(), symbol, side, qty, price))
    return jsonify({"ok": True, "message": "معامله آزمایشی ثبت شد؛ سفارش واقعی ارسال نشده است."})

@app.route("/api/plans")
def plans():
    return jsonify({"plans": [
        {"name": "رایگان", "price": 0, "features": ["قیمت‌های بازار", "سیگنال‌های پایه", "تاریخچه محدود"]},
        {"name": "تحلیلی", "price": None, "features": ["گزارش‌های تحلیلی", "تاریخچه بیشتر", "هشدارها"], "status": "طرح پیشنهادی؛ پرداخت هنوز پیاده‌سازی نشده"},
        {"name": "حرفه‌ای", "price": None, "features": ["داشبورد پیشرفته", "ابزارهای بک‌تست", "گزارش عملکرد"], "status": "طرح پیشنهادی؛ پرداخت هنوز پیاده‌سازی نشده"}
    ], "payment_enabled": False})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.getenv("PORT", "5000")), debug=False)
